from flask import Flask, request
from styles import stylish_styles

app = Flask(__name__)

@app.route("/")
def hello_world():
    content = """
    <h1>🏢 Centaurus Free WiFi</h1>
    <form action="/login" method="post">
        Username: <input type="text" name="username">
        Password: <input type="password" name="password">
        <input type="submit" value="Login">
    </form>
    """
    return stylish_styles(content)

@app.route("/login", methods=["POST"])
def login():
    user = request.form.get("username")
    return stylish_styles(
        f"Successfully logged in as <b>{user}</b>"
        )

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8080)
